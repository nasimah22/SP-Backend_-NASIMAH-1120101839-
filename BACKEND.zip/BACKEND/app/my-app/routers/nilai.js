const express = require('express')
const routerNilai = express.Router()
const connection = require('../db/db.js')
const ctrNilai= require('../controllers/nilai')

routerNilai.get('/nilai',ctrNilai.getNilai)
routerNilai.get('/nilai/:nim',ctrNilai.getNilaiByNim)
routerNilai.get('/nilai',ctrNilai.getNilaiByNimBySemester)
routerNilai.post('/nilai',ctrNilai.create)
routerNilai.put('/nilai/:nim/:kdMk',ctrNilai.update)
routerNilai.delete('/nilai/:nim/:kdMk',ctrNilai.delete )

module.exports = routerNilai