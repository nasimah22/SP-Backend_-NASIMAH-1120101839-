const mysql = require("mysql");

// create a connection to the database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'espe'
});

// open the MySQL connection
connection.connect(error => {
    if (error) throw error;
    console.log("Succeesfully connected to the database.");
});

module.exports = connection