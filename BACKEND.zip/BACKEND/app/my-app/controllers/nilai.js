const connection = require("../db/db");

module.exports = {
    getNilai:  (req,res) => {
        const qstring = "SELECT * FROM nilai";
        connection.query(qstring, (err,data) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send({
                    message : err.message || "Terjadi kesalahan saat get data"
                });
            }
            else res.send(data)
        });
    },

    getNilaiByNim: (req,res) => {
        const qstring = `SELECT matakuliah.kdMk, matakuliah.matakuliah, nilai.dosen, matakuliah.sks, nilai.semester, nilai.nilai 
                        FROM nilai 
                        INNER JOIN matakuliah 
                        ON nilai.kdMk = matakuliah.kdMk 
                        WHERE nilai.nim = ${req.params.nim};`;
    connection.query(qstring, (err,data) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send({
                message : err.message || "Terjadi kesalahan saat get data"
            });
        }
        else res.send(data)
    });
    },

    getNilaiByNimBySemester: (req,res) => {
        const qstring = `SELECT matakuliah.kdMk, matakuliah.matakuliah, nilai.dosen, matakuliah.sks, nilai.semester, nilai.nilai 
                        FROM nilai 
                        INNER JOIN matakuliah 
                        ON nilai.kdMk = matakuliah.kdMk 
                        WHERE nilai.nim = ${req.params.nim} AND nilai.semester = ${req.params.semester};`;
    connection.query(qstring, (err,data) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send({
                message : err.message || "Terjadi kesalahan saat get data"
            });
        }
        else res.send(data)
    });
    },

    create: (req,res) => {
        const nilaiBaru = req.body;
    
        connection.query("INSERT INTO nilai SET ?", nilaiBaru,(err) => {
            if (err) {
                console.log("error:", err);
                res.status(500).send({
                    message : err.message || "Terjadi kesalahan saat insert data"
                });
            }
            else
                res.send(nilaiBaru)
        });
    },

    update: (req, res) => {
        const nim = req.params.nim;
        const kdMk = req.params.kdMk;
        const nilai = req.body;
        const qstring = `UPDATE nilai
                        SET dosen = '${nilai.dosen}', semester = '${nilai.semester}', nilai = '${nilai.nilai}'
                        WHERE nim = '${nim}' AND kdMk = '${kdMk}'`;
        connection.query(qstring, (err,data) => {
            if(err) {
                res.status(500).send({
                    message: "Error updating nilai with NIM" + nim
                });
            }
            else if(data.affectedRows == 0){
                res.status(404).send({
                    message: `Not found nilai with NIM ${nim}.`
                });
            }
            else {
                console.log("update nilai:", { nim: nim, ...nilai});
                res.send({ nim: nim, ...nilai});
            }
        })
    },

    delete: (req,res) => {
        const nim = req.params.nim;
        const qstring = `DELETE FROM nilai WHERE nim = '${nim}'`
        connection.query(qstring, (err, data) => {
            if(err) {
                res.status(500).send({
                    message: "Error deleting nilai with NIM" + nim
                });
            }
            else if(data.affectedRows == 0){
                res.status(404).send({
                    message: `Not found nilai with NIM ${nim}.`
                })
            }
            else res.send(`nilai dengan nim = ${nim} telah terhapus`)
        });
    },
}