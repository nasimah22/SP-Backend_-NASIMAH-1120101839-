const express = require('express');
const app = express();

const routerMhs = require('./routers/mahasiswa')
const routerMk = require('./routers/matakuliah')
const routerNilai = require('./routers/nilai')

const port = 5000;

//untuk menerima req.body
app.use(express.json())
app.use(express.urlencoded({extended: true}))

//Mount Routing
app.use(routerMhs);
app.use(routerMk);
app.use(routerNilai);

// app.get('/',(req,res)=>{
//     res.send('Get - Home')
// })

//ambil parameter

app.get('/nim', ()=>{
    console.log(req.query.nim)
   })

app.listen(port,()=>{
    console.log(`Server berjalan pada port ${port}`)
})
